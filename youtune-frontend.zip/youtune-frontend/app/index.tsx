import * as React from 'react';
import { Image, View } from 'react-native';
import { Input } from '~/components/ui/input';
import { Text } from '~/components/ui/text';
import { Separator } from '~/components/ui/separator';
import { Button } from '~/components/ui/button';


export default function Screen() {
  const [progress, setProgress] = React.useState(78);
  const [value,setValue] = React.useState("");

  function updateProgressValue() {
    setProgress(Math.floor(Math.random() * 100));
  }
  return (
    <View className="flex justify-center items-center">
      <View className="flex w-[88Vw] items center pt-10">

        <Image src='' alt='Logo'/>

        <View className='flex w-[100%] items-center p-10 gap-7'>
            <Text>Digite o seu URL</Text>
            <Input
            placeholder='Type url here!'
            value={value}
            onChangeText={setValue}
            aria-errormessage='inputError'
            className='outline-none'
            aria-labelledby='url'
            onKeyPress={()=>{ }/* função que chama a consulta ou algo do tipo */}
            />

            {/* Depois pode adicionar uma imagem ao Button */}
            <Button className='relative left-[39.042vw] bottom-[68px] p-5' onPress={()=>{} /* Mesma função do Input onKeyPress */}><Text>→</Text></Button>

        </View>
      <Separator className='' />
      <View>
        {/* Conteúdo que aparecer ao jogar o URL */}
      </View>
      </View>
    </View>
  );
}
